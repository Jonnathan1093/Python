from setuptools import setup

setup(
    name ="miFuncion",
    version ="1.0",
    description ="realizar sumas y comprobar si esta impar",
    author = "Jonnathan Heras",
    author_email ="jonnathan1093@gmail.com",
    url = "https://retrogeeksla.blogspot.com/",
    packages=["paquetes"]
)