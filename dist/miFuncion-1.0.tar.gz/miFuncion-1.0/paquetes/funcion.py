def esPar(numero):
    if numero % 2 == 0:
        # print("El numero es par")
        return True
    else:
        # print("El numero es impar")
        return False

def suma(num1, num2):
    return num1+num2 




